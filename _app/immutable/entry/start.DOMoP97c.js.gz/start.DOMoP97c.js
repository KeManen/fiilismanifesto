import{a as t}from"../chunks/entry.CKWU2PjW.js";export{t as start};
